var searchData=
[
  ['buffer_5fsize_0',['BUFFER_SIZE',['../dpdk-server_8c.html#a6b20d41d6252e9871430c242cb1a56e7',1,'dpdk-server.c']]]
];
