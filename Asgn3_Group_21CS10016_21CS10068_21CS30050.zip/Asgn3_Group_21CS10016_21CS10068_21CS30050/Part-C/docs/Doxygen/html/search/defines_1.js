var searchData=
[
  ['max_5fevents_0',['MAX_EVENTS',['../dpdk-server_8c.html#ae42954bb8545d24e3e9dcde5920c9a0b',1,'dpdk-server.c']]]
];
