var searchData=
[
  ['epfd_0',['epfd',['../dpdk-server_8c.html#ad9ea3108c3907d7dedaf4ee7283bef1d',1,'dpdk-server.c']]],
  ['ev_1',['ev',['../dpdk-server_8c.html#aec0e547134563cdcc13c7545b1f2abbf',1,'dpdk-server.c']]],
  ['events_2',['events',['../dpdk-server_8c.html#acc3fe99e84abfb562e4afca193743074',1,'dpdk-server.c']]]
];
