var searchData=
[
  ['dpdk_2dserver_2ec_0',['dpdk-server.c',['../dpdk-server_8c.html',1,'']]]
];
