var searchData=
[
  ['main_0',['main',['../dpdk-server_8c.html#a0ddf1224851353fc92bfbff6f499fa97',1,'dpdk-server.c']]],
  ['max_5fevents_1',['MAX_EVENTS',['../dpdk-server_8c.html#ae42954bb8545d24e3e9dcde5920c9a0b',1,'dpdk-server.c']]],
  ['message_2',['message',['../structresp.html#abfacb7efd9f3a18dc6fc546166ca0e7d',1,'resp']]]
];
