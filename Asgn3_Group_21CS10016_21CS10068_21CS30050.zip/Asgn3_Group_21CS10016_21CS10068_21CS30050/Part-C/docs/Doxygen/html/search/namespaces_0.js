var searchData=
[
  ['client_0',['client',['../namespaceclient.html',1,'']]]
];
