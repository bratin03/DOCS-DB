var searchData=
[
  ['server_0',['server',['../namespaceserver.html',1,'']]]
];
