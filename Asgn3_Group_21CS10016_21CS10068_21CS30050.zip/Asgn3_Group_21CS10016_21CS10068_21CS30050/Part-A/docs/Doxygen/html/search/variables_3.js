var searchData=
[
  ['left_0',['left',['../classnode.html#a7cbff55ff448f557223f79299056e9b1',1,'node']]]
];
