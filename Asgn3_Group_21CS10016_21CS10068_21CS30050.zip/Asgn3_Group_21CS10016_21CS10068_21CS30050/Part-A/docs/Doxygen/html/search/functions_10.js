var searchData=
[
  ['waltest_0',['WALTest',['../classWALTest.html#a70503b87b2461cf103a140e9ad30515a',1,'WALTest']]],
  ['write_5fahead_5flog_1',['write_ahead_log',['../classwrite__ahead__log.html#ae2f64acb4080ce5f5501d852ef48ee3f',1,'write_ahead_log']]]
];
