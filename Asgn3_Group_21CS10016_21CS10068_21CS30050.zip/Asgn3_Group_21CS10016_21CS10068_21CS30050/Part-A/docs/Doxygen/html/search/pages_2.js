var searchData=
[
  ['part_20a_0',['DOCS-DB Documentation - Part A',['../index.html',1,'']]]
];
