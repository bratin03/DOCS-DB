var searchData=
[
  ['cases_0',['Use Cases',['../index.html#usecases',1,'']]],
  ['clear_1',['clear',['../classwrite__ahead__log.html#a95d9042c77538b5df74b01b9cb75e9f4',1,'write_ahead_log']]],
  ['cmd_5fto_5fenum_2',['cmd_to_enum',['../repl_8cpp.html#ad55a821de4ff206c614c067e8daaa65f',1,'repl.cpp']]],
  ['collect_5flevels_3',['collect_levels',['../classlevel.html#a0f346d6ef3fb77c0123696e71de8265e',1,'level']]],
  ['color_4',['color',['../classnode.html#abca3cc6b5874dfd90e404925680fa8ef',1,'node']]],
  ['command_5floop_5',['command_loop',['../repl_8cpp.html#a331911851a3ae109ed97f6c86369d34a',1,'repl.cpp']]],
  ['commands_6',['commands',['../repl_8cpp.html#a033f2c2ba101d1649bd36de7783782f0',1,'repl.cpp']]],
  ['considerations_7',['Performance Considerations',['../index.html#performance',1,'']]],
  ['create_5ffilename_5fbased_5fon_5flevel_8',['create_filename_based_on_level',['../classlevel.html#a898530d957c7361a9f408b2ce99d3231',1,'level']]]
];
