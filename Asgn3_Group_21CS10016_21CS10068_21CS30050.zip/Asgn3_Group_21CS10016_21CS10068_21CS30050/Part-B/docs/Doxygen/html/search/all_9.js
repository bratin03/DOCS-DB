var searchData=
[
  ['server_2ecpp_0',['server.cpp',['../server_8cpp.html',1,'']]],
  ['server_5fip_1',['SERVER_IP',['../client_8cpp.html#a28d06fc286f28044ed3380969700ff3f',1,'SERVER_IP:&#160;client.cpp'],['../server_8cpp.html#a28d06fc286f28044ed3380969700ff3f',1,'SERVER_IP:&#160;server.cpp']]],
  ['server_5fport_2',['SERVER_PORT',['../client_8cpp.html#ac42367fe5c999ec6650de83e9d72fe8c',1,'client.cpp']]],
  ['sockfd_3',['sockfd',['../dpdk__server_8cpp.html#ad2c8fb3df3a737e0685e902870a611d2',1,'dpdk_server.cpp']]]
];
