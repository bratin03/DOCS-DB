var searchData=
[
  ['handleclient_0',['handleClient',['../server_8cpp.html#a28ce186ce771194512785b1d1d5310c0',1,'server.cpp']]]
];
