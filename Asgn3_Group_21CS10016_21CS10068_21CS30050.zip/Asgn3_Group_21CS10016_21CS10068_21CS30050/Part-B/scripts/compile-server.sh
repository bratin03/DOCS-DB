mkdir -p ../bin

g++ ../src/server.cpp -o ../bin/server -std=c++20 -pthread -O3