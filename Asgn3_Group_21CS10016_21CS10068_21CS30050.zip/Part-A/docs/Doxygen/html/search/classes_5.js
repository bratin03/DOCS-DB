var searchData=
[
  ['waltest_0',['WALTest',['../classWALTest.html',1,'']]],
  ['write_5fahead_5flog_1',['write_ahead_log',['../classwrite__ahead__log.html',1,'']]]
];
