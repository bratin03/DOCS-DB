var searchData=
[
  ['tombstone_0',['TOMBSTONE',['../types_8h.html#abbfa2c01002e78dec9027ab712a296e7',1,'types.h']]]
];
