var searchData=
[
  ['delete_5fall_5fsegments_0',['delete_all_segments',['../classlevel.html#a16fdfa4bd69201d1b15d51ac0ecb0018',1,'level']]],
  ['delete_5ftree_1',['delete_tree',['../classnode.html#ad9171a0fa7b1a51364a0da531b92ee60',1,'node::delete_tree()'],['../classred__black__tree.html#a5ad2a7d61ee5e34b3ba5ef39cda7c262',1,'red_black_tree::delete_tree()']]],
  ['drop_5ftable_2',['drop_table',['../classlsm__tree.html#ae56ce4c08dd0eff303ee966d9a912f0a',1,'lsm_tree']]]
];
