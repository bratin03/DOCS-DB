var searchData=
[
  ['color_0',['color',['../classnode.html#abca3cc6b5874dfd90e404925680fa8ef',1,'node']]]
];
