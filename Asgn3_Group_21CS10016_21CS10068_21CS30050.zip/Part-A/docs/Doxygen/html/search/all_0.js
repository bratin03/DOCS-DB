var searchData=
[
  ['a_0',['DOCS-DB Documentation - Part A',['../index.html',1,'']]],
  ['append_1',['append',['../classwrite__ahead__log.html#a5e9fb95850e2b9147500b03c058e7b0c',1,'write_ahead_log']]],
  ['architecture_2',['Architecture',['../index.html#architecture',1,'']]]
];
