var searchData=
[
  ['pair_0',['pair',['../classnode.html#ac677a491ae1a228645f75e7780d933d5',1,'node']]],
  ['parent_1',['parent',['../classnode.html#a5e88137f1d0e2f7a940bccf4c3d3a4d3',1,'node']]]
];
