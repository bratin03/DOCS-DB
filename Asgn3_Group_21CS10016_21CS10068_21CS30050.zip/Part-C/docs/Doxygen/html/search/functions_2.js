var searchData=
[
  ['close_0',['close',['../classclient_1_1RESPClient.html#a1495117847f9ed49ad1da1d9ed46ae4f',1,'client::RESPClient']]],
  ['connect_1',['connect',['../classclient_1_1RESPClient.html#add3647cef1ff6e8330c7ee3141e1d16a',1,'client::RESPClient']]]
];
