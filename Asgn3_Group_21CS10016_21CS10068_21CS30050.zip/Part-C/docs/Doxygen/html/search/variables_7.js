var searchData=
[
  ['port_0',['port',['../classclient_1_1RESPClient.html#a33ec56bf58bf43309adad28687277fe9',1,'client.RESPClient.port'],['../namespaceserver.html#af7b39ba3404872fb79e91b08ed362768',1,'server.port']]]
];
