var searchData=
[
  ['client_2epy_0',['client.py',['../client_8py.html',1,'']]]
];
