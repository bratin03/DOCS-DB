var searchData=
[
  ['sock_0',['sock',['../classclient_1_1RESPClient.html#a08f4a1fe868b1ca3a1254b58eb4b2897',1,'client::RESPClient']]],
  ['sockfd_1',['sockfd',['../dpdk-server_8c.html#ad2c8fb3df3a737e0685e902870a611d2',1,'dpdk-server.c']]]
];
