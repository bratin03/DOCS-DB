var searchData=
[
  ['max_5fevents_0',['MAX_EVENTS',['../dpdk__server_8cpp.html#ae42954bb8545d24e3e9dcde5920c9a0b',1,'dpdk_server.cpp']]],
  ['max_5fpacket_5fcount_1',['MAX_PACKET_COUNT',['../server_8cpp.html#a11e88723c999cbe5c3aaac1bc9604667',1,'server.cpp']]]
];
