var searchData=
[
  ['buffer_5fsize_0',['BUFFER_SIZE',['../dpdk__server_8cpp.html#a6b20d41d6252e9871430c242cb1a56e7',1,'BUFFER_SIZE:&#160;dpdk_server.cpp'],['../server_8cpp.html#a6b20d41d6252e9871430c242cb1a56e7',1,'BUFFER_SIZE:&#160;server.cpp']]]
];
