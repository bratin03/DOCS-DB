var searchData=
[
  ['sockfd_0',['sockfd',['../dpdk__server_8cpp.html#ad2c8fb3df3a737e0685e902870a611d2',1,'dpdk_server.cpp']]]
];
