sudo tc qdisc add dev enp1s0 root netem delay 100ms loss 5%
