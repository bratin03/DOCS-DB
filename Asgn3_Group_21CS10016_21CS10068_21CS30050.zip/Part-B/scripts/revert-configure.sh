sudo tc qdisc del dev enp1s0 root
